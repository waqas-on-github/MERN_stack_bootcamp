# Replicate the Following Output

`Assests are Provided!`

![Project 1](./Credit%20card%20landing%20page.png)
